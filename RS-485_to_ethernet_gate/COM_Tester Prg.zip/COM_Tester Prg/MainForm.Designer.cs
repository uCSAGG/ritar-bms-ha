﻿namespace COM_Tester
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.serialP = new System.IO.Ports.SerialPort(this.components);
            this.btnSend = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.cmbSendPeriod = new System.Windows.Forms.ComboBox();
            this.chkStreaming = new System.Windows.Forms.CheckBox();
            this.txtData0 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.nmSendQty = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.txtData31 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.optHex = new System.Windows.Forms.RadioButton();
            this.optDec = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.txtData2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtData30 = new System.Windows.Forms.TextBox();
            this.txtData15 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txtData29 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtData28 = new System.Windows.Forms.TextBox();
            this.txtData14 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtData27 = new System.Windows.Forms.TextBox();
            this.txtData13 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtData26 = new System.Windows.Forms.TextBox();
            this.txtData12 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtData25 = new System.Windows.Forms.TextBox();
            this.txtData11 = new System.Windows.Forms.TextBox();
            this.txtData1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtData24 = new System.Windows.Forms.TextBox();
            this.txtData10 = new System.Windows.Forms.TextBox();
            this.txtData16 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtData9 = new System.Windows.Forms.TextBox();
            this.txtData3 = new System.Windows.Forms.TextBox();
            this.txtData17 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtData8 = new System.Windows.Forms.TextBox();
            this.txtData4 = new System.Windows.Forms.TextBox();
            this.txtData18 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtData5 = new System.Windows.Forms.TextBox();
            this.txtData19 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtData6 = new System.Windows.Forms.TextBox();
            this.txtData20 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtData7 = new System.Windows.Forms.TextBox();
            this.txtData21 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtData22 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtData23 = new System.Windows.Forms.TextBox();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.imgList = new System.Windows.Forms.ImageList(this.components);
            this.listProcess = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ctxMnu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuSelToCpbAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSelToCpbData = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.lblQtySent = new System.Windows.Forms.Label();
            this.lblQtyReceive = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbPortNumber = new System.Windows.Forms.ComboBox();
            this.cmbPortSpeed = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.cmbPortParity = new System.Windows.Forms.ComboBox();
            this.tmrSend = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.labelURL = new System.Windows.Forms.Label();
            this.tmrReceive = new System.Windows.Forms.Timer(this.components);
            this.statStrip = new System.Windows.Forms.StatusStrip();
            this.lblStat = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSendQty)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.ctxMnu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.statStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialP
            // 
            this.serialP.BaudRate = 19200;
            this.serialP.DtrEnable = true;
            this.serialP.RtsEnable = true;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(359, 106);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(107, 42);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send once";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.cmbSendPeriod);
            this.groupBox1.Controls.Add(this.chkStreaming);
            this.groupBox1.Controls.Add(this.txtData0);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtData31);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtData2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.btnSend);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.txtData30);
            this.groupBox1.Controls.Add(this.txtData15);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.txtData29);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.txtData28);
            this.groupBox1.Controls.Add(this.txtData14);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.txtData27);
            this.groupBox1.Controls.Add(this.txtData13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txtData26);
            this.groupBox1.Controls.Add(this.txtData12);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.txtData25);
            this.groupBox1.Controls.Add(this.txtData11);
            this.groupBox1.Controls.Add(this.txtData1);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtData24);
            this.groupBox1.Controls.Add(this.txtData10);
            this.groupBox1.Controls.Add(this.txtData16);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtData9);
            this.groupBox1.Controls.Add(this.txtData3);
            this.groupBox1.Controls.Add(this.txtData17);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtData8);
            this.groupBox1.Controls.Add(this.txtData4);
            this.groupBox1.Controls.Add(this.txtData18);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtData5);
            this.groupBox1.Controls.Add(this.txtData19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtData6);
            this.groupBox1.Controls.Add(this.txtData20);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtData7);
            this.groupBox1.Controls.Add(this.txtData21);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.txtData22);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtData23);
            this.groupBox1.Location = new System.Drawing.Point(327, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(476, 159);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Packet parameters";
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(315, 132);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(31, 18);
            this.label38.TabIndex = 89;
            this.label38.Text = "ms";
            // 
            // cmbSendPeriod
            // 
            this.cmbSendPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSendPeriod.FormattingEnabled = true;
            this.cmbSendPeriod.Items.AddRange(new object[] {
            "50",
            "100",
            "200",
            "300",
            "500",
            "1000",
            "2000",
            "3000",
            "5000"});
            this.cmbSendPeriod.Location = new System.Drawing.Point(245, 126);
            this.cmbSendPeriod.Name = "cmbSendPeriod";
            this.cmbSendPeriod.Size = new System.Drawing.Size(64, 21);
            this.cmbSendPeriod.TabIndex = 88;
            // 
            // chkStreaming
            // 
            this.chkStreaming.Location = new System.Drawing.Point(245, 100);
            this.chkStreaming.Name = "chkStreaming";
            this.chkStreaming.Size = new System.Drawing.Size(108, 24);
            this.chkStreaming.TabIndex = 87;
            this.chkStreaming.Text = "Send periodically";
            this.chkStreaming.UseVisualStyleBackColor = true;
            this.chkStreaming.CheckedChanged += new System.EventHandler(this.chkStreaming_CheckedChanged);
            // 
            // txtData0
            // 
            this.txtData0.Location = new System.Drawing.Point(13, 29);
            this.txtData0.MaxLength = 3;
            this.txtData0.Name = "txtData0";
            this.txtData0.Size = new System.Drawing.Size(26, 20);
            this.txtData0.TabIndex = 7;
            this.txtData0.Text = "00";
            this.txtData0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nmSendQty);
            this.groupBox4.Location = new System.Drawing.Point(130, 102);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(101, 48);
            this.groupBox4.TabIndex = 86;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Number of bytes";
            // 
            // nmSendQty
            // 
            this.nmSendQty.Location = new System.Drawing.Point(25, 18);
            this.nmSendQty.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.nmSendQty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmSendQty.Name = "nmSendQty";
            this.nmSendQty.Size = new System.Drawing.Size(53, 20);
            this.nmSendQty.TabIndex = 45;
            this.nmSendQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmSendQty.ValueChanged += new System.EventHandler(this.nmSendQty_ValueChanged);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(21, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "0";
            // 
            // txtData31
            // 
            this.txtData31.Enabled = false;
            this.txtData31.Location = new System.Drawing.Point(441, 66);
            this.txtData31.MaxLength = 3;
            this.txtData31.Name = "txtData31";
            this.txtData31.Size = new System.Drawing.Size(26, 20);
            this.txtData31.TabIndex = 78;
            this.txtData31.Text = "00";
            this.txtData31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.optHex);
            this.groupBox2.Controls.Add(this.optDec);
            this.groupBox2.Location = new System.Drawing.Point(16, 102);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(108, 48);
            this.groupBox2.TabIndex = 83;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Data format";
            // 
            // optHex
            // 
            this.optHex.AutoSize = true;
            this.optHex.Checked = true;
            this.optHex.Location = new System.Drawing.Point(9, 18);
            this.optHex.Name = "optHex";
            this.optHex.Size = new System.Drawing.Size(42, 17);
            this.optHex.TabIndex = 80;
            this.optHex.TabStop = true;
            this.optHex.Text = "hex";
            this.optHex.UseVisualStyleBackColor = true;
            this.optHex.Click += new System.EventHandler(this.optHex_Click);
            // 
            // optDec
            // 
            this.optDec.AutoSize = true;
            this.optDec.Location = new System.Drawing.Point(57, 18);
            this.optDec.Name = "optDec";
            this.optDec.Size = new System.Drawing.Size(43, 17);
            this.optDec.TabIndex = 81;
            this.optDec.TabStop = true;
            this.optDec.Text = "dec";
            this.optDec.UseVisualStyleBackColor = true;
            this.optDec.Click += new System.EventHandler(this.optDec_Click);
            // 
            // label6
            // 
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(49, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 12);
            this.label6.TabIndex = 19;
            this.label6.Text = "1";
            // 
            // txtData2
            // 
            this.txtData2.Enabled = false;
            this.txtData2.Location = new System.Drawing.Point(70, 29);
            this.txtData2.MaxLength = 3;
            this.txtData2.Name = "txtData2";
            this.txtData2.Size = new System.Drawing.Size(26, 20);
            this.txtData2.TabIndex = 12;
            this.txtData2.Text = "00";
            this.txtData2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(446, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 12);
            this.label3.TabIndex = 79;
            this.label3.Text = "31";
            // 
            // label35
            // 
            this.label35.Enabled = false;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.Location = new System.Drawing.Point(21, 53);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(15, 12);
            this.label35.TabIndex = 56;
            this.label35.Text = "16";
            // 
            // label7
            // 
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(80, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 12);
            this.label7.TabIndex = 20;
            this.label7.Text = "2";
            // 
            // label34
            // 
            this.label34.Enabled = false;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.Location = new System.Drawing.Point(49, 53);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 12);
            this.label34.TabIndex = 57;
            this.label34.Text = "17";
            // 
            // txtData30
            // 
            this.txtData30.Enabled = false;
            this.txtData30.Location = new System.Drawing.Point(414, 66);
            this.txtData30.MaxLength = 3;
            this.txtData30.Name = "txtData30";
            this.txtData30.Size = new System.Drawing.Size(26, 20);
            this.txtData30.TabIndex = 70;
            this.txtData30.Text = "00";
            this.txtData30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData15
            // 
            this.txtData15.Enabled = false;
            this.txtData15.Location = new System.Drawing.Point(441, 29);
            this.txtData15.MaxLength = 3;
            this.txtData15.Name = "txtData15";
            this.txtData15.Size = new System.Drawing.Size(26, 20);
            this.txtData15.TabIndex = 46;
            this.txtData15.Text = "00";
            this.txtData15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(107, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 12);
            this.label8.TabIndex = 21;
            this.label8.Text = "3";
            // 
            // label33
            // 
            this.label33.Enabled = false;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.Location = new System.Drawing.Point(80, 53);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 12);
            this.label33.TabIndex = 58;
            this.label33.Text = "18";
            // 
            // txtData29
            // 
            this.txtData29.Enabled = false;
            this.txtData29.Location = new System.Drawing.Point(385, 66);
            this.txtData29.MaxLength = 3;
            this.txtData29.Name = "txtData29";
            this.txtData29.Size = new System.Drawing.Size(26, 20);
            this.txtData29.TabIndex = 69;
            this.txtData29.Text = "00";
            this.txtData29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(446, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 12);
            this.label1.TabIndex = 47;
            this.label1.Text = "15";
            // 
            // label9
            // 
            this.label9.Enabled = false;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(135, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 12);
            this.label9.TabIndex = 22;
            this.label9.Text = "4";
            // 
            // label32
            // 
            this.label32.Enabled = false;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(107, 53);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(15, 12);
            this.label32.TabIndex = 59;
            this.label32.Text = "19";
            // 
            // txtData28
            // 
            this.txtData28.Enabled = false;
            this.txtData28.Location = new System.Drawing.Point(356, 66);
            this.txtData28.MaxLength = 3;
            this.txtData28.Name = "txtData28";
            this.txtData28.Size = new System.Drawing.Size(26, 20);
            this.txtData28.TabIndex = 68;
            this.txtData28.Text = "00";
            this.txtData28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData14
            // 
            this.txtData14.Enabled = false;
            this.txtData14.Location = new System.Drawing.Point(414, 29);
            this.txtData14.MaxLength = 3;
            this.txtData14.Name = "txtData14";
            this.txtData14.Size = new System.Drawing.Size(26, 20);
            this.txtData14.TabIndex = 36;
            this.txtData14.Text = "00";
            this.txtData14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.Enabled = false;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(164, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 12);
            this.label10.TabIndex = 23;
            this.label10.Text = "5";
            // 
            // label31
            // 
            this.label31.Enabled = false;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(135, 53);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(15, 12);
            this.label31.TabIndex = 60;
            this.label31.Text = "20";
            // 
            // txtData27
            // 
            this.txtData27.Enabled = false;
            this.txtData27.Location = new System.Drawing.Point(327, 66);
            this.txtData27.MaxLength = 3;
            this.txtData27.Name = "txtData27";
            this.txtData27.Size = new System.Drawing.Size(26, 20);
            this.txtData27.TabIndex = 67;
            this.txtData27.Text = "00";
            this.txtData27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData13
            // 
            this.txtData13.Enabled = false;
            this.txtData13.Location = new System.Drawing.Point(385, 29);
            this.txtData13.MaxLength = 3;
            this.txtData13.Name = "txtData13";
            this.txtData13.Size = new System.Drawing.Size(26, 20);
            this.txtData13.TabIndex = 35;
            this.txtData13.Text = "00";
            this.txtData13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.Enabled = false;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(194, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "6";
            // 
            // label30
            // 
            this.label30.Enabled = false;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(164, 53);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(15, 12);
            this.label30.TabIndex = 61;
            this.label30.Text = "21";
            // 
            // txtData26
            // 
            this.txtData26.Enabled = false;
            this.txtData26.Location = new System.Drawing.Point(299, 66);
            this.txtData26.MaxLength = 3;
            this.txtData26.Name = "txtData26";
            this.txtData26.Size = new System.Drawing.Size(26, 20);
            this.txtData26.TabIndex = 66;
            this.txtData26.Text = "00";
            this.txtData26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData12
            // 
            this.txtData12.Enabled = false;
            this.txtData12.Location = new System.Drawing.Point(356, 29);
            this.txtData12.MaxLength = 3;
            this.txtData12.Name = "txtData12";
            this.txtData12.Size = new System.Drawing.Size(26, 20);
            this.txtData12.TabIndex = 34;
            this.txtData12.Text = "00";
            this.txtData12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.Enabled = false;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(221, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "7";
            // 
            // label29
            // 
            this.label29.Enabled = false;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(194, 53);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(15, 12);
            this.label29.TabIndex = 62;
            this.label29.Text = "22";
            // 
            // txtData25
            // 
            this.txtData25.Enabled = false;
            this.txtData25.Location = new System.Drawing.Point(270, 66);
            this.txtData25.MaxLength = 3;
            this.txtData25.Name = "txtData25";
            this.txtData25.Size = new System.Drawing.Size(26, 20);
            this.txtData25.TabIndex = 65;
            this.txtData25.Text = "00";
            this.txtData25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData11
            // 
            this.txtData11.Enabled = false;
            this.txtData11.Location = new System.Drawing.Point(327, 29);
            this.txtData11.MaxLength = 3;
            this.txtData11.Name = "txtData11";
            this.txtData11.Size = new System.Drawing.Size(26, 20);
            this.txtData11.TabIndex = 33;
            this.txtData11.Text = "00";
            this.txtData11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData1
            // 
            this.txtData1.Enabled = false;
            this.txtData1.Location = new System.Drawing.Point(41, 29);
            this.txtData1.MaxLength = 3;
            this.txtData1.Name = "txtData1";
            this.txtData1.Size = new System.Drawing.Size(26, 20);
            this.txtData1.TabIndex = 11;
            this.txtData1.Text = "00";
            this.txtData1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label28
            // 
            this.label28.Enabled = false;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(221, 53);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(15, 12);
            this.label28.TabIndex = 63;
            this.label28.Text = "23";
            // 
            // txtData24
            // 
            this.txtData24.Enabled = false;
            this.txtData24.Location = new System.Drawing.Point(242, 66);
            this.txtData24.MaxLength = 3;
            this.txtData24.Name = "txtData24";
            this.txtData24.Size = new System.Drawing.Size(26, 20);
            this.txtData24.TabIndex = 64;
            this.txtData24.Text = "00";
            this.txtData24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData10
            // 
            this.txtData10.Enabled = false;
            this.txtData10.Location = new System.Drawing.Point(299, 29);
            this.txtData10.MaxLength = 3;
            this.txtData10.Name = "txtData10";
            this.txtData10.Size = new System.Drawing.Size(26, 20);
            this.txtData10.TabIndex = 32;
            this.txtData10.Text = "00";
            this.txtData10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData16
            // 
            this.txtData16.Enabled = false;
            this.txtData16.Location = new System.Drawing.Point(13, 66);
            this.txtData16.MaxLength = 3;
            this.txtData16.Name = "txtData16";
            this.txtData16.Size = new System.Drawing.Size(26, 20);
            this.txtData16.TabIndex = 48;
            this.txtData16.Text = "00";
            this.txtData16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.Enabled = false;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(419, 53);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 12);
            this.label13.TabIndex = 77;
            this.label13.Text = "30";
            // 
            // txtData9
            // 
            this.txtData9.Enabled = false;
            this.txtData9.Location = new System.Drawing.Point(270, 29);
            this.txtData9.MaxLength = 3;
            this.txtData9.Name = "txtData9";
            this.txtData9.Size = new System.Drawing.Size(26, 20);
            this.txtData9.TabIndex = 31;
            this.txtData9.Text = "00";
            this.txtData9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData3
            // 
            this.txtData3.Enabled = false;
            this.txtData3.Location = new System.Drawing.Point(98, 29);
            this.txtData3.MaxLength = 3;
            this.txtData3.Name = "txtData3";
            this.txtData3.Size = new System.Drawing.Size(26, 20);
            this.txtData3.TabIndex = 13;
            this.txtData3.Text = "00";
            this.txtData3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData17
            // 
            this.txtData17.Enabled = false;
            this.txtData17.Location = new System.Drawing.Point(41, 66);
            this.txtData17.MaxLength = 3;
            this.txtData17.Name = "txtData17";
            this.txtData17.Size = new System.Drawing.Size(26, 20);
            this.txtData17.TabIndex = 49;
            this.txtData17.Text = "00";
            this.txtData17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label15
            // 
            this.label15.Enabled = false;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(389, 53);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 12);
            this.label15.TabIndex = 76;
            this.label15.Text = "29";
            // 
            // txtData8
            // 
            this.txtData8.Enabled = false;
            this.txtData8.Location = new System.Drawing.Point(242, 29);
            this.txtData8.MaxLength = 3;
            this.txtData8.Name = "txtData8";
            this.txtData8.Size = new System.Drawing.Size(26, 20);
            this.txtData8.TabIndex = 30;
            this.txtData8.Text = "00";
            this.txtData8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData4
            // 
            this.txtData4.Enabled = false;
            this.txtData4.Location = new System.Drawing.Point(127, 29);
            this.txtData4.MaxLength = 3;
            this.txtData4.Name = "txtData4";
            this.txtData4.Size = new System.Drawing.Size(26, 20);
            this.txtData4.TabIndex = 14;
            this.txtData4.Text = "00";
            this.txtData4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData18
            // 
            this.txtData18.Enabled = false;
            this.txtData18.Location = new System.Drawing.Point(70, 66);
            this.txtData18.MaxLength = 3;
            this.txtData18.Name = "txtData18";
            this.txtData18.Size = new System.Drawing.Size(26, 20);
            this.txtData18.TabIndex = 50;
            this.txtData18.Text = "00";
            this.txtData18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.Enabled = false;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(360, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 12);
            this.label16.TabIndex = 75;
            this.label16.Text = "28";
            // 
            // label17
            // 
            this.label17.Enabled = false;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(419, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 12);
            this.label17.TabIndex = 44;
            this.label17.Text = "14";
            // 
            // txtData5
            // 
            this.txtData5.Enabled = false;
            this.txtData5.Location = new System.Drawing.Point(156, 29);
            this.txtData5.MaxLength = 3;
            this.txtData5.Name = "txtData5";
            this.txtData5.Size = new System.Drawing.Size(26, 20);
            this.txtData5.TabIndex = 15;
            this.txtData5.Text = "00";
            this.txtData5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData19
            // 
            this.txtData19.Enabled = false;
            this.txtData19.Location = new System.Drawing.Point(98, 66);
            this.txtData19.MaxLength = 3;
            this.txtData19.Name = "txtData19";
            this.txtData19.Size = new System.Drawing.Size(26, 20);
            this.txtData19.TabIndex = 51;
            this.txtData19.Text = "00";
            this.txtData19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.Enabled = false;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(332, 53);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 12);
            this.label18.TabIndex = 74;
            this.label18.Text = "27";
            // 
            // label19
            // 
            this.label19.Enabled = false;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(389, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 12);
            this.label19.TabIndex = 43;
            this.label19.Text = "13";
            // 
            // txtData6
            // 
            this.txtData6.Enabled = false;
            this.txtData6.Location = new System.Drawing.Point(185, 29);
            this.txtData6.MaxLength = 3;
            this.txtData6.Name = "txtData6";
            this.txtData6.Size = new System.Drawing.Size(26, 20);
            this.txtData6.TabIndex = 16;
            this.txtData6.Text = "00";
            this.txtData6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData20
            // 
            this.txtData20.Enabled = false;
            this.txtData20.Location = new System.Drawing.Point(127, 66);
            this.txtData20.MaxLength = 3;
            this.txtData20.Name = "txtData20";
            this.txtData20.Size = new System.Drawing.Size(26, 20);
            this.txtData20.TabIndex = 52;
            this.txtData20.Text = "00";
            this.txtData20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.Enabled = false;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(305, 53);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(15, 12);
            this.label25.TabIndex = 73;
            this.label25.Text = "26";
            // 
            // label20
            // 
            this.label20.Enabled = false;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(360, 15);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 12);
            this.label20.TabIndex = 42;
            this.label20.Text = "12";
            // 
            // txtData7
            // 
            this.txtData7.Enabled = false;
            this.txtData7.Location = new System.Drawing.Point(213, 29);
            this.txtData7.MaxLength = 3;
            this.txtData7.Name = "txtData7";
            this.txtData7.Size = new System.Drawing.Size(26, 20);
            this.txtData7.TabIndex = 17;
            this.txtData7.Text = "00";
            this.txtData7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData21
            // 
            this.txtData21.Enabled = false;
            this.txtData21.Location = new System.Drawing.Point(156, 66);
            this.txtData21.MaxLength = 3;
            this.txtData21.Name = "txtData21";
            this.txtData21.Size = new System.Drawing.Size(26, 20);
            this.txtData21.TabIndex = 53;
            this.txtData21.Text = "00";
            this.txtData21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label26
            // 
            this.label26.Enabled = false;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(278, 53);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(15, 12);
            this.label26.TabIndex = 72;
            this.label26.Text = "25";
            // 
            // label21
            // 
            this.label21.Enabled = false;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(332, 15);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(15, 12);
            this.label21.TabIndex = 41;
            this.label21.Text = "11";
            // 
            // label24
            // 
            this.label24.Enabled = false;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(250, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(10, 12);
            this.label24.TabIndex = 38;
            this.label24.Text = "8";
            // 
            // txtData22
            // 
            this.txtData22.Enabled = false;
            this.txtData22.Location = new System.Drawing.Point(185, 66);
            this.txtData22.MaxLength = 3;
            this.txtData22.Name = "txtData22";
            this.txtData22.Size = new System.Drawing.Size(26, 20);
            this.txtData22.TabIndex = 54;
            this.txtData22.Text = "00";
            this.txtData22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label27
            // 
            this.label27.Enabled = false;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(250, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(15, 12);
            this.label27.TabIndex = 71;
            this.label27.Text = "24";
            // 
            // label22
            // 
            this.label22.Enabled = false;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(305, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(15, 12);
            this.label22.TabIndex = 40;
            this.label22.Text = "10";
            // 
            // label23
            // 
            this.label23.Enabled = false;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(278, 15);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(10, 12);
            this.label23.TabIndex = 39;
            this.label23.Text = "9";
            // 
            // txtData23
            // 
            this.txtData23.Enabled = false;
            this.txtData23.Location = new System.Drawing.Point(213, 66);
            this.txtData23.MaxLength = 3;
            this.txtData23.Name = "txtData23";
            this.txtData23.Size = new System.Drawing.Size(26, 20);
            this.txtData23.TabIndex = 55;
            this.txtData23.Text = "00";
            this.txtData23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(76, 124);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(107, 28);
            this.btnClearAll.TabIndex = 4;
            this.btnClearAll.Text = "Clear history";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // imgList
            // 
            this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
            this.imgList.TransparentColor = System.Drawing.Color.Transparent;
            this.imgList.Images.SetKeyName(0, "SEND");
            this.imgList.Images.SetKeyName(1, "RECEIVE");
            // 
            // listProcess
            // 
            this.listProcess.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listProcess.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listProcess.ContextMenuStrip = this.ctxMnu;
            this.listProcess.FullRowSelect = true;
            this.listProcess.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listProcess.HideSelection = false;
            this.listProcess.Location = new System.Drawing.Point(-1, 168);
            this.listProcess.Name = "listProcess";
            this.listProcess.ShowGroups = false;
            this.listProcess.Size = new System.Drawing.Size(816, 318);
            this.listProcess.SmallImageList = this.imgList;
            this.listProcess.TabIndex = 5;
            this.listProcess.UseCompatibleStateImageBehavior = false;
            this.listProcess.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Date";
            this.columnHeader1.Width = 180;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Size";
            this.columnHeader2.Width = 35;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Data";
            this.columnHeader3.Width = 590;
            // 
            // ctxMnu
            // 
            this.ctxMnu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuSelToCpbAll,
            this.mnuSelToCpbData});
            this.ctxMnu.Name = "ctxMnu";
            this.ctxMnu.Size = new System.Drawing.Size(221, 48);
            // 
            // mnuSelToCpbAll
            // 
            this.mnuSelToCpbAll.Name = "mnuSelToCpbAll";
            this.mnuSelToCpbAll.Size = new System.Drawing.Size(220, 22);
            this.mnuSelToCpbAll.Text = "Selected to clipboard (All)";
            this.mnuSelToCpbAll.Click += new System.EventHandler(this.mnuSelToCpbAll_Click);
            // 
            // mnuSelToCpbData
            // 
            this.mnuSelToCpbData.Name = "mnuSelToCpbData";
            this.mnuSelToCpbData.Size = new System.Drawing.Size(220, 22);
            this.mnuSelToCpbData.Text = "Selected to clipboard (Data)";
            this.mnuSelToCpbData.Click += new System.EventHandler(this.mnuSelToCpbData_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Sent packages";
            // 
            // lblQtySent
            // 
            this.lblQtySent.ForeColor = System.Drawing.Color.Blue;
            this.lblQtySent.Location = new System.Drawing.Point(122, 85);
            this.lblQtySent.Name = "lblQtySent";
            this.lblQtySent.Size = new System.Drawing.Size(61, 15);
            this.lblQtySent.TabIndex = 8;
            this.lblQtySent.Text = "000000000";
            this.lblQtySent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblQtyReceive
            // 
            this.lblQtyReceive.ForeColor = System.Drawing.Color.Green;
            this.lblQtyReceive.Location = new System.Drawing.Point(122, 104);
            this.lblQtyReceive.Name = "lblQtyReceive";
            this.lblQtyReceive.Size = new System.Drawing.Size(61, 13);
            this.lblQtyReceive.TabIndex = 9;
            this.lblQtyReceive.Text = "000000000";
            this.lblQtyReceive.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "Received packages";
            // 
            // cmbPortNumber
            // 
            this.cmbPortNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortNumber.FormattingEnabled = true;
            this.cmbPortNumber.Location = new System.Drawing.Point(238, 32);
            this.cmbPortNumber.Name = "cmbPortNumber";
            this.cmbPortNumber.Size = new System.Drawing.Size(72, 21);
            this.cmbPortNumber.TabIndex = 51;
            // 
            // cmbPortSpeed
            // 
            this.cmbPortSpeed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortSpeed.FormattingEnabled = true;
            this.cmbPortSpeed.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.cmbPortSpeed.Location = new System.Drawing.Point(238, 81);
            this.cmbPortSpeed.Name = "cmbPortSpeed";
            this.cmbPortSpeed.Size = new System.Drawing.Size(72, 21);
            this.cmbPortSpeed.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(237, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 53;
            this.label4.Text = "Port:";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(237, 63);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 15);
            this.label36.TabIndex = 54;
            this.label36.Text = "Boudrate:";
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(237, 113);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(38, 15);
            this.label37.TabIndex = 57;
            this.label37.Text = "Parity:";
            // 
            // cmbPortParity
            // 
            this.cmbPortParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortParity.FormattingEnabled = true;
            this.cmbPortParity.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cmbPortParity.Location = new System.Drawing.Point(238, 131);
            this.cmbPortParity.Name = "cmbPortParity";
            this.cmbPortParity.Size = new System.Drawing.Size(72, 21);
            this.cmbPortParity.TabIndex = 56;
            // 
            // tmrSend
            // 
            this.tmrSend.Interval = 500;
            this.tmrSend.Tick += new System.EventHandler(this.tmrSend_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(7, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(195, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            // 
            // labelURL
            // 
            this.labelURL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelURL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(100)))), ((int)(((byte)(0)))));
            this.labelURL.Location = new System.Drawing.Point(89, 4);
            this.labelURL.Name = "labelURL";
            this.labelURL.Size = new System.Drawing.Size(127, 22);
            this.labelURL.TabIndex = 59;
            this.labelURL.Text = "vkmodule.com.ua";
            this.labelURL.Click += new System.EventHandler(this.LabelURLClick);
            // 
            // tmrReceive
            // 
            this.tmrReceive.Enabled = true;
            this.tmrReceive.Tick += new System.EventHandler(this.tmrReceive_Tick);
            // 
            // statStrip
            // 
            this.statStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStat});
            this.statStrip.Location = new System.Drawing.Point(0, 485);
            this.statStrip.Name = "statStrip";
            this.statStrip.Size = new System.Drawing.Size(814, 22);
            this.statStrip.TabIndex = 60;
            this.statStrip.Text = "statusStrip1";
            // 
            // lblStat
            // 
            this.lblStat.ForeColor = System.Drawing.Color.Red;
            this.lblStat.Name = "lblStat";
            this.lblStat.Size = new System.Drawing.Size(40, 17);
            this.lblStat.Text = "lblStat";
            this.lblStat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 507);
            this.Controls.Add(this.statStrip);
            this.Controls.Add(this.labelURL);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.cmbPortParity);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbPortSpeed);
            this.Controls.Add(this.cmbPortNumber);
            this.Controls.Add(this.listProcess);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblQtyReceive);
            this.Controls.Add(this.lblQtySent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(830, 374);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "COM-port Tester";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmSendQty)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ctxMnu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.statStrip.ResumeLayout(false);
            this.statStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer tmrSend;
        private System.Windows.Forms.ComboBox cmbPortParity;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cmbPortNumber;
        private System.Windows.Forms.ComboBox cmbPortSpeed;
        private System.Windows.Forms.CheckBox chkStreaming;
        private System.Windows.Forms.Label labelURL;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label4;

        #endregion

        private System.IO.Ports.SerialPort serialP;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtData0;
        private System.Windows.Forms.ImageList imgList;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtData7;
        private System.Windows.Forms.TextBox txtData6;
        private System.Windows.Forms.TextBox txtData5;
        private System.Windows.Forms.TextBox txtData4;
        private System.Windows.Forms.TextBox txtData3;
        private System.Windows.Forms.TextBox txtData2;
        private System.Windows.Forms.TextBox txtData1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtData14;
        private System.Windows.Forms.TextBox txtData13;
        private System.Windows.Forms.TextBox txtData12;
        private System.Windows.Forms.TextBox txtData11;
        private System.Windows.Forms.TextBox txtData10;
        private System.Windows.Forms.TextBox txtData9;
        private System.Windows.Forms.TextBox txtData8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ListView listProcess;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.NumericUpDown nmSendQty;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblQtySent;
        private System.Windows.Forms.Label lblQtyReceive;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtData15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtData31;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtData30;
        private System.Windows.Forms.TextBox txtData29;
        private System.Windows.Forms.TextBox txtData28;
        private System.Windows.Forms.TextBox txtData27;
        private System.Windows.Forms.TextBox txtData26;
        private System.Windows.Forms.TextBox txtData25;
        private System.Windows.Forms.TextBox txtData24;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtData23;
        private System.Windows.Forms.TextBox txtData22;
        private System.Windows.Forms.TextBox txtData21;
        private System.Windows.Forms.TextBox txtData20;
        private System.Windows.Forms.TextBox txtData19;
        private System.Windows.Forms.TextBox txtData18;
        private System.Windows.Forms.TextBox txtData17;
        private System.Windows.Forms.TextBox txtData16;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.RadioButton optDec;
        private System.Windows.Forms.RadioButton optHex;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Timer tmrReceive;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cmbSendPeriod;
        private System.Windows.Forms.StatusStrip statStrip;
        private System.Windows.Forms.ToolStripStatusLabel lblStat;
        private System.Windows.Forms.ContextMenuStrip ctxMnu;
        private System.Windows.Forms.ToolStripMenuItem mnuSelToCpbAll;
        private System.Windows.Forms.ToolStripMenuItem mnuSelToCpbData;
    }
}

