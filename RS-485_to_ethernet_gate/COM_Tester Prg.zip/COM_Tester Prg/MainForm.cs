﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.IO.Ports;

namespace COM_Tester
{
    public partial class MainForm : Form
    {
        byte[] packSend = new byte[32];

        bool bNoError = true;   // Была ли ошибка преобразования байта из текста


        //массив текстовых полей (в которые вводятся данные для отправки)
        TextBox[] txtDataArray;
        
		
        public MainForm()
        {
            try
            {
                InitializeComponent();

                lblQtySent.Text = "0";
                lblQtyReceive.Text = "0";
                lblStat.Text = "";
                //обнуление значений полей принятых и отправленных пакетов
                txtDataArray = new TextBox[] { txtData0, txtData1, txtData2, txtData3, txtData4, txtData5, txtData6, txtData7, txtData8, txtData9, txtData10, txtData11, txtData12, txtData13, txtData14, txtData15, txtData16, txtData17, txtData18, txtData19, txtData20, txtData21, txtData22, txtData23, txtData24, txtData25, txtData26, txtData27, txtData28, txtData29, txtData30, txtData31 };
                foreach (TextBox crl in txtDataArray)
                {
                    //добавляем для всех тектовых полей дополнительную функцию, которая вызывается 
                    //при наступлении события изменения текста и клика по текстовому полю
                    crl.TextChanged += new EventHandler(eventTextChanges);
                    crl.Click += new EventHandler(eventTextSelects);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

		private void MainForm_Load(object sender, EventArgs e)
		{
            try
            {
			    string[] ports = SerialPort.GetPortNames(); //получаем список доступных СОМ-портов
			    int i;
			
			    for(i = 0; i < ports.Length; i++)
				    cmbPortNumber.Items.Add(ports[i]); //заполняем ими список

                if (ports.Length >= 1)
                {
                    cmbPortNumber.Text = ports[0];
                    cmbPortSpeed.Text = "19200";		//устанавливаем первый в списке СОМ-порт по умолчанию
                    cmbPortParity.Text = "None";
                    cmbSendPeriod.SelectedIndex = 2;
                }
                else
                {
                    MessageBox.Show("COM port is not available!", "COM port", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Application.Exit();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
		
		
		
		
		private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                lblStat.Text = "";

                if (!CkechTextBoxes())  // Если текстовые окна заполнены с ошибками, неичего не отсылаем
                {
                    lblStat.Text = "Wrong packet data";
                    return;
                }


                if (serialP.IsOpen)
                {
                    ListViewItem lvi;
                    string message = "";

                    int PacketLen;
                    byte[] mes = new byte[32];			//переменная, которая будет содержать данные для отправки
                    PacketLen = (byte)nmSendQty.Value;	//длина пакета данных в байтах
                    int i;

                    for (i = 0; i < nmSendQty.Value; i++)
                    {
                        if (optHex.Checked)			//если данные в 16-ричном виде
                        {
                            mes[i] = StrHexToByte(txtDataArray[i].Text);		//преобразование из 16-ричного вида в байт
                            message = message + ByteToStrHex(mes[i]) + " ";	    //формируем сообщение для отображения в ListView
                        }
                        else			// данные в 10-тичном виде
                        {
                            mes[i] = Byte.Parse(txtDataArray[i].Text);		            //преобразование 10-тичных чисел в байт
                            message = message + StrDecToStrHex(txtDataArray[i].Text) + " ";	//формируем сообщение для отображения в ListView
                        }

                        serialP.Write(mes, i, 1);
                    }

                    //формируем строку с датой отправления данных
                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    lblQtySent.Text = ((Int32)(Int32.Parse(lblQtySent.Text) + 1)).ToString();

                    lvi = new ListViewItem();
                    lvi.ImageKey = "SEND";
                    lvi.Text = DT;
                    lvi.SubItems.Add(PacketLen.ToString());
                    lvi.SubItems.Add(message);
                    listProcess.Items.Add(lvi);
                    listProcess.Items[listProcess.Items.Count - 1].EnsureVisible();
                }
                else
                    lblStat.Text = "COM-port is closed";
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		
		
		
		
        










        // ПРОВЕРКА ПРАВИЛЬНОСТИ ЗАПОЛНЕНИЯ ТЕКСТОВЫХ ОКОН

        private bool CkechTextBoxes()
        {
            try
            {
                bool bOK = true;
                int i;
                
                for (i = 0; i < nmSendQty.Value; i++)
                {
                    if (optHex.Checked)	    // данные в 16-ричном виде
                        StrHexToByte(txtDataArray[i].Text);
                    else		        	// данные в 10-ричном виде
                        StrDecToByte(txtDataArray[i].Text);

                    if (!bNoError)
                    {
                        bOK = false;
                        txtDataArray[i].ForeColor = Color.Red;
                    }
                }
                return bOK;
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

		
		//------------------------------------------------------------------------------------------------
        //
		// StrHex <-> Byte

		//функция преобразования 16-ричной строки в Байт
		private byte StrHexToByte(string sHex)
        {
            try
            {
                byte ret = 0;
                bNoError = true;

                string hxH = "";
                string hxL = "";
                if (sHex.Length == 2)
                {
                    hxH = sHex.Substring(0, 1);
                    hxL = sHex.Substring(1, 1);
                }
                else if (sHex.Length == 1)
                {
                    hxL = sHex.Substring(0, 1);
                }
                else
                {
                    bNoError = false;
                    return 0;
                }

                if (hxH == "0") ret = 0;
                else if (hxH == "1") ret = 16;
                else if (hxH == "2") ret = 16 * 2;
                else if (hxH == "3") ret = 16 * 3;
                else if (hxH == "4") ret = 16 * 4;
                else if (hxH == "5") ret = 16 * 5;
                else if (hxH == "6") ret = 16 * 6;
                else if (hxH == "7") ret = 16 * 7;
                else if (hxH == "8") ret = 16 * 8;
                else if (hxH == "9") ret = 16 * 9;
                else if (hxH == "A" || hxH == "a") ret = 16 * 10;
                else if (hxH == "B" || hxH == "b") ret = 16 * 11;
                else if (hxH == "C" || hxH == "c") ret = 16 * 12;
                else if (hxH == "D" || hxH == "d") ret = 16 * 13;
                else if (hxH == "E" || hxH == "e") ret = 16 * 14;
                else if (hxH == "F" || hxH == "f") ret = 16 * 15;

                if (hxL == "0") ret += 0;
                else if (hxL == "1") ret += 1;
                else if (hxL == "2") ret += 2;
                else if (hxL == "3") ret += 3;
                else if (hxL == "4") ret += 4;
                else if (hxL == "5") ret += 5;
                else if (hxL == "6") ret += 6;
                else if (hxL == "7") ret += 7;
                else if (hxL == "8") ret += 8;
                else if (hxL == "9") ret += 9;
                else if (hxL == "A" || hxL == "a") ret += 10;
                else if (hxL == "B" || hxL == "b") ret += 11;
                else if (hxL == "C" || hxL == "c") ret += 12;
                else if (hxL == "D" || hxL == "d") ret += 13;
                else if (hxL == "E" || hxL == "e") ret += 14;
                else if (hxL == "F" || hxL == "f") ret += 15;
                else
                {
                    bNoError = false;
                    return 0;
                }

                return ret;
            }
            catch (Exception ex) 
            {
                bNoError = false;
                return 0;
            }
        }
		
		
		//функция преобразования Байта в 16-ричную строку
		private string ByteToStrHex(byte b)
        {
            try
            {
                int  iTmpH = b / (byte)16;
                int  iTmpL = b % (byte)16;
                string ret   = "";

                if (iTmpH < 10)
                    ret = iTmpH.ToString();
                else
                {
                    if (iTmpH == 10) ret = "A";
                    if (iTmpH == 11) ret = "B";
                    if (iTmpH == 12) ret = "C";
                    if (iTmpH == 13) ret = "D";
                    if (iTmpH == 14) ret = "E";
                    if (iTmpH == 15) ret = "F";
                }

                if (iTmpL < 10)
                    ret += iTmpL.ToString();
                else
                {
                    if (iTmpL == 10) ret += "A";
                    if (iTmpL == 11) ret += "B";
                    if (iTmpL == 12) ret += "C";
                    if (iTmpL == 13) ret += "D";
                    if (iTmpL == 14) ret += "E";
                    if (iTmpL == 15) ret += "F";
                }

                return ret;
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
                return "";
            }
        }
		
		
		
		
		
		//------------------------------------------------------------------------------------------------
        //
		// StrDec <-> Byte
        
        private byte StrDecToByte(string sDec)
        {
            try
            {
                bNoError = true;
                return byte.Parse (sDec);
            }
            catch (Exception ex) 
            {
                bNoError = false;
                return 0;
            }
        }
		
		
		
		//функция преобразования Байта в 10-ричную строку
		private string ByteToStrDec(byte b)
        {
            try
            {
                return b.ToString();
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
                return "";
            }
        }



		
		//------------------------------------------------------------------------------------------------
        //
		// StrDec <-> StrHex
        
		//функция преобразования 10-ричной строки в 16-ричную строку
		private string StrDecToStrHex(string sDec)
        {
            try
            {
                bNoError = true;
                byte b = StrDecToByte(sDec);

                if (!bNoError)
                    return "";
                
                return ByteToStrHex(b);
            }
            catch (Exception ex) 
            {
                bNoError = false;
                return "";
            }
        }

		//функция преобразования 16-ричной строки в 10-ричную строку
		private string StrHexToStrDec(string sHex)
        {
            try
            {
                bNoError = true;
                byte b = StrHexToByte(sHex);

                if (!bNoError)
                    return "";
                
                return ByteToStrDec(b);
            }
            catch (Exception ex) 
            {
                bNoError = false;
                return "";
            }
        }







		
		
		//обработчик события нажатия кнопки "Очистить"
		private void btnClearAll_Click(object sender, EventArgs e)
        {
            lblQtySent.Text    = "0";
            lblQtyReceive.Text = "0";
            listProcess.Items.Clear();
        }
		
		
		//функция деактивации полей ввода данных и их надписей
		private void setVisText()
        {
            int vis = 0;
            foreach (TextBox crl in txtDataArray)	//проходим все текстовые поля в массиве
            {
                crl.Enabled = false;			//отключаем их
                if (vis < nmSendQty.Value)		//если необходимо активировать
                    crl.Enabled = true;//активируем
                vis++;//наращиваем счетчик
            }
        }
		
		
		//обработчик события выделения текста в текстовом поле
		public void eventTextSelects(object sender, EventArgs e)
        {
            TextBox b = (TextBox)sender;
            b.SelectAll();
        }


        public void eventTextChanges(object sender, EventArgs e)
        {
            TextBox b = (TextBox)sender;
            b.ForeColor = Color.Black;
        }
        
		
		
		//обработчик события изменения значения в поле ввода байт для отправления
		private void nmSendQty_ValueChanged(object sender, EventArgs e)
        {
            setVisText();
        }



        //обработчик события нажатия на кнопку HEX(формат данных 16-ричный)
        private void optHex_Click(object sender, EventArgs e)
        {
            try
            {
                if (optHex.Checked)	    //если нам нужно преобразовать данные из 10-тичного формата в 16-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrDecToStrHex(crl.Text);
                }
                else	//если нужно преобразовать из 16-тичного формата в 10-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrHexToStrDec(crl.Text);
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
        //обработчик события нажатия на кнопку DEC(формат данных 10-ричный)
        private void optDec_Click(object sender, EventArgs e)
        {
            try
            {
                if (optHex.Checked)	    //если нам нужно преобразовать данные из 10-тичного формата в 16-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrDecToStrHex(crl.Text);
                }
                else	//если нужно преобразовать из 16-тичного формата в 10-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrHexToStrDec(crl.Text);
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		
		
        

        
        
        void LabelURLClick(object sender, EventArgs e)
        {
            try
            {
        	    System.Diagnostics.Process.Start("http://www.vkmodule.com.ua");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        


        private void chkStreaming_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (chkStreaming.Checked)
                {
                    tmrSend.Interval = int.Parse(cmbSendPeriod.Text);
                    tmrSend.Start();
                }
                else
                {
                    tmrSend.Stop();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void tmrSend_Tick(object sender, EventArgs e)
        {
            try
            {
                tmrSend.Interval = int.Parse(cmbSendPeriod.Text);
                btnSend_Click(this, null);
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }

        private void tmrReceive_Tick(object sender, EventArgs e)
        {
            try
            {
                byte[] inp;
                int inpQty = 0;
                ListViewItem lvi;
                string sReceiveDT = "";
                string message = "";

                // Если изменились настройки порта, перенастраиваем порт
                if (serialP.PortName != cmbPortNumber.Text)
                {
                    serialP.Close();
                    serialP.PortName = cmbPortNumber.Text;
                }
                if (serialP.BaudRate != int.Parse(cmbPortSpeed.Text))
                {
                    serialP.Close();
                    serialP.BaudRate = int.Parse(cmbPortSpeed.Text);
                }
                if ((cmbPortParity.Text == "Odd") && (serialP.Parity != System.IO.Ports.Parity.Odd))
                {
                    serialP.Close();
                    serialP.Parity = System.IO.Ports.Parity.Odd;
                }
                if ((cmbPortParity.Text == "Even") && (serialP.Parity != System.IO.Ports.Parity.Even))
                {
                    serialP.Close();
                    serialP.Parity = System.IO.Ports.Parity.Even;
                }
                if ((cmbPortParity.Text == "None") && (serialP.Parity != System.IO.Ports.Parity.None))
                {
                    serialP.Close();
                    serialP.Parity = System.IO.Ports.Parity.None;
                }


                // Если порт закрыт, открываем
                if (!serialP.IsOpen)
                    serialP.Open();

                if (serialP.IsOpen)
                {
                    inp = new Byte[4096];
                    inpQty = 0;

                    if (serialP.BytesToRead > 0)	//если пришли данные
                    {
                        sReceiveDT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                        inpQty = serialP.BytesToRead;				//определяем количество байт, которые пришли
                        serialP.Read(inp, 0, serialP.BytesToRead);	//считываем данные


                        // ПОКАЗ В СПИСКЕ
                        if (inpQty > 0)
                        {
                            message = "";

                            for (Int32 i = 0; i < inpQty; i++)
                                message += " " + ByteToStrHex(inp[i]);		//формируем сообщение для отображения в ListView

                            lvi = new ListViewItem();
                            lvi.ImageKey = "RECEIVE";
                            lvi.Text = sReceiveDT;
                            lvi.SubItems.Add(inpQty.ToString());
                            lvi.SubItems.Add(message);
                            listProcess.Items.Add(lvi);
                            listProcess.Items[listProcess.Items.Count - 1].EnsureVisible();

                            lblQtyReceive.Text = ((Int32)(Int32.Parse(lblQtyReceive.Text) + 1)).ToString();
                        }
                    }
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //  SELECTED NJ CLIPBOARD

        private void mnuSelToCpbAll_Click(object sender, EventArgs e)
        {
            try
            {
                if (listProcess.SelectedItems.Count < 1)
                    return;

                string sText = "";
                foreach (ListViewItem lvi in listProcess.SelectedItems)
                {
                    sText += lvi.Text + " - " + lvi.SubItems[1].Text + " - " + lvi.SubItems[2].Text + "\r\n";
                }
                Clipboard.SetText(sText);
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }

        private void mnuSelToCpbData_Click(object sender, EventArgs e)
        {
            try
            {
                if (listProcess.SelectedItems.Count < 1)
                    return;

                string sText = "";
                foreach (ListViewItem lvi in listProcess.SelectedItems)
                {
                    sText += lvi.SubItems[2].Text + "\r\n";
                }
                Clipboard.SetText(sText);
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }


        
    }
}












