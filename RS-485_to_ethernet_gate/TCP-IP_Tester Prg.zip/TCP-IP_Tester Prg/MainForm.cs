﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Text.RegularExpressions;


namespace TCP_IP_Tester
{
	
  
    public partial class MainForm : Form
    {
		//делегат для обращения к компоненту ListView из потока опроса сокета
        public delegate void listViewUpdateCallBack(string param1, string param2, string param3);
        
        System.Net.Sockets.TcpClient clientSocket = new System.Net.Sockets.TcpClient();
        //поток чтения-записи
        NetworkStream serverStream = default(NetworkStream);
        Thread ctThread;
        string patternIP;		//регулярное выражение для проверки правильности введенного ІР-адреса
        TextBox[] txtDataArray;	//массив текстовых полей (в которые вводятся данные для отправки)
        bool bNoError = true;   // Была ли ошибка преобразования байта из текста
        
        
        public MainForm()
        {
            try
            {
                InitializeComponent();
                patternIP = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
                txtDataArray = new TextBox[] { txtData0, txtData1, txtData2, txtData3, txtData4, txtData5, txtData6, txtData7, txtData8, txtData9, txtData10, txtData11, txtData12, txtData13, txtData14, txtData15, txtData16, txtData17, txtData18, txtData19, txtData20, txtData21, txtData22, txtData23, txtData24, txtData25, txtData26, txtData27, txtData28, txtData29, txtData30, txtData31 };
                cmbSendPeriod.SelectedIndex = 0;
                lblStat.Text = "";

                foreach (TextBox crl in txtDataArray)
                {
                    //добавляем для всех тектовых полей дополнительную функцию, которая вызывается 
                    //при наступлении события изменения текста и клика по текстовому полю
                    crl.TextChanged += new EventHandler(eventTextChanges);
                    crl.Click += new EventHandler(eventTextSelects);
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		
        
        //обработчик нажатия кнопки "Отправить"
		private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                lblStat.Text = "";

                if (!CkechTextBoxes())  // Если текстовые окна заполнены с ошибками, неичего не отсылаем
                {
                    lblStat.Text = "Wrong packet data";
                    return;
                }


			    if (clientSocket.Connected)		// если соединение установлено
                {
                    String message = "";
                    Byte[] mes = new Byte[128];			//переменная, которая будет содержать данные для отправки
                    int i = 0;						// счетчик

                    for (i = 0; i < nmSendQty.Value; i++)
                    {
                        if (optHex.Checked)			//если данные в 16-ричном виде
                        {
                            mes[i] = StrHexToByte(txtDataArray[i].Text);		//преобразование из 16-ричного вида в байт
                            message = message + ByteToStrHex(mes[i]) + " ";	    //формируем сообщение для отображения в ListView
                        }
                        else			// данные в 10-тичном виде
                        {
                            mes[i] = Byte.Parse(txtDataArray[i].Text);		            //преобразование 10-тичных чисел в байт
                            message = message + StrDecToStrHex(txtDataArray[i].Text) + " ";	//формируем сообщение для отображения в ListView
                        }
				    }

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    //формируем строку с датой отправления данных
                    listProcess.Items.Add(DT);
                    listProcess.Items[listProcess.Items.Count - 1].SubItems.Add(nmSendQty.Value.ToString());
                    listProcess.Items[listProcess.Items.Count - 1].SubItems.Add(message);
                    listProcess.Items[listProcess.Items.Count - 1].ImageIndex = 0;
                    this.listProcess.EnsureVisible(listProcess.Items.Count - 1);

                    serverStream.Write(mes, 0, (int)nmSendQty.Value);
                    serverStream.Flush();
                }
                else
                {
            	    if (!chkStreaming.Checked)
                	    lblStat.Text = "You must connect to be able sending data";
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		
		
		//обработчик нажатия кнопки "Connect"
		private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                int port = int.Parse(txtPort.Text);		//чтение из текстового поля номера порта
                if ((port > 64000) || (port < 20))		//если это число и оно не между 20 и 64000 - выводим сообщение об ошибке
                {
                    lblStat.Text = "Not valid port. Enter port number between 20-64000.";
                    return;
                }
            }
            catch (Exception ex)
            {
				//если в текстовом поле не число - выводим сообщение об ошибке
                lblStat.Text = "Not valid port. " + ex.Message;
                return;
            }

            Match m = Regex.Match(maskedTextBox2.Text, patternIP);//проверяем правильно ли введен ІР-адрес в текстовое поле
            if (m.Success)
            {
                //   MessageBox.Show("Good", "Good", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            else
            {   //если нет - выводим сообщение об ошибке
                lblStat.Text = "Not valid IP Address";
                return;
            }

            try
            {
                if (!clientSocket.Connected)//если нет соединения
                {

                    clientSocket = new System.Net.Sockets.TcpClient();//получаем сокет
                    clientSocket.Connect(maskedTextBox2.Text, Int32.Parse(txtPort.Text));
                    //подключаемся к ІР и порту, введенных в текстовые поля
                    serverStream = clientSocket.GetStream();
                    //получаем поток
                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    //формируем строку с датой и временем при котором произошло подключение и добавляем в ListView
                    listProcess.Items.Add(DT + " (Connected)");
                    this.listProcess.EnsureVisible(listProcess.Items.Count - 1);
                    clientSocket.ReceiveBufferSize = 8192;
                    //выставляем размер буфера - 8192 байта
                    ctThread = new Thread(getMessage);
                    //создаем поток, в котором будет происходит прием данных и запускаем его
                    ctThread.Start();
                }
            }
            catch (Exception ex)//если подключение не удалось - выводим сообщение об ошибке
            {
                lblStat.Text = ex.Message;
            }
        }
		
		
		//тело потока приема сообщений
		private void getMessage()
        {
            while (true)//бесконечный цикл
            {
            	//try
            	//{
	                if (clientSocket.Connected)//если подключение установлено
	                {
	                    serverStream = clientSocket.GetStream();			//получаем поток
	                    int buffSize = 0;
	                    int bytesRead= 0;
	                    byte[] inStream = new byte[10025];					// инициализируем массив для приема данных
	                    buffSize = clientSocket.ReceiveBufferSize;			//получаем размер буфера
	                    bytesRead = serverStream.Read(inStream, 0, buffSize);//считываем данные из потока
	                    
	                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
	                    //формируем строку с датой и временем получения данных
	                    string message = "";
	                    for (int i = 0; i < bytesRead; i++)
	                    {
	                        message = message + ByteToStrHex(inStream[i]) + " ";
	                        //формируем сообщения для вывода в ListView в 16-ричном виде
	                    }
	                    
	                    if (bytesRead > 0)
	                    {
	                        listViewUpdate(DT, bytesRead.ToString(), message);
	                        //если данные получены - выводим их в ListView
	                    }
	                }
                //}
            	//catch (Exception ex)
	            //{
	            //    MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
	            //}
            }
        }
		
		
		
		//обработчик нажатия кнопки "Disconnect"
		private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)
                {
                    ctThread.Abort();
                
                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listProcess.Items.Add(DT + " (Disconnected)");
                    this.listProcess.EnsureVisible(listProcess.Items.Count - 1);
                    clientSocket.Client.Disconnect(true);
                    //формируем строку с датой отключения, добавляем ее в ListView и отключаемся
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }







        // ПРОВЕРКА ПРАВИЛЬНОСТИ ЗАПОЛНЕНИЯ ТЕКСТОВЫХ ОКОН

        private bool CkechTextBoxes()
        {
            try
            {
                bool bOK = true;
                int i;

                for (i = 0; i < nmSendQty.Value; i++)
                {
                    if (optHex.Checked)	    // данные в 16-ричном виде
                        StrHexToByte(txtDataArray[i].Text);
                    else		        	// данные в 10-ричном виде
                        StrDecToByte(txtDataArray[i].Text);

                    if (!bNoError)
                    {
                        bOK = false;
                        txtDataArray[i].ForeColor = Color.Red;
                    }
                }
                return bOK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }


        //------------------------------------------------------------------------------------------------
        //
        // StrHex <-> Byte

        //функция преобразования 16-ричной строки в Байт
        private byte StrHexToByte(string sHex)
        {
            try
            {
                byte ret = 0;
                bNoError = true;

                string hxH = "";
                string hxL = "";
                if (sHex.Length == 2)
                {
                    hxH = sHex.Substring(0, 1);
                    hxL = sHex.Substring(1, 1);
                }
                else if (sHex.Length == 1)
                {
                    hxL = sHex.Substring(0, 1);
                }
                else
                {
                    bNoError = false;
                    return 0;
                }

                if (hxH == "0") ret = 0;
                else if (hxH == "1") ret = 16;
                else if (hxH == "2") ret = 16 * 2;
                else if (hxH == "3") ret = 16 * 3;
                else if (hxH == "4") ret = 16 * 4;
                else if (hxH == "5") ret = 16 * 5;
                else if (hxH == "6") ret = 16 * 6;
                else if (hxH == "7") ret = 16 * 7;
                else if (hxH == "8") ret = 16 * 8;
                else if (hxH == "9") ret = 16 * 9;
                else if (hxH == "A" || hxH == "a") ret = 16 * 10;
                else if (hxH == "B" || hxH == "b") ret = 16 * 11;
                else if (hxH == "C" || hxH == "c") ret = 16 * 12;
                else if (hxH == "D" || hxH == "d") ret = 16 * 13;
                else if (hxH == "E" || hxH == "e") ret = 16 * 14;
                else if (hxH == "F" || hxH == "f") ret = 16 * 15;

                if (hxL == "0") ret += 0;
                else if (hxL == "1") ret += 1;
                else if (hxL == "2") ret += 2;
                else if (hxL == "3") ret += 3;
                else if (hxL == "4") ret += 4;
                else if (hxL == "5") ret += 5;
                else if (hxL == "6") ret += 6;
                else if (hxL == "7") ret += 7;
                else if (hxL == "8") ret += 8;
                else if (hxL == "9") ret += 9;
                else if (hxL == "A" || hxL == "a") ret += 10;
                else if (hxL == "B" || hxL == "b") ret += 11;
                else if (hxL == "C" || hxL == "c") ret += 12;
                else if (hxL == "D" || hxL == "d") ret += 13;
                else if (hxL == "E" || hxL == "e") ret += 14;
                else if (hxL == "F" || hxL == "f") ret += 15;
                else
                {
                    bNoError = false;
                    return 0;
                }

                return ret;
            }
            catch (Exception ex)
            {
                bNoError = false;
                return 0;
            }
        }


        //функция преобразования Байта в 16-ричную строку
        private string ByteToStrHex(byte b)
        {
            try
            {
                int iTmpH = b / (byte)16;
                int iTmpL = b % (byte)16;
                string ret = "";

                if (iTmpH < 10)
                    ret = iTmpH.ToString();
                else
                {
                    if (iTmpH == 10) ret = "A";
                    if (iTmpH == 11) ret = "B";
                    if (iTmpH == 12) ret = "C";
                    if (iTmpH == 13) ret = "D";
                    if (iTmpH == 14) ret = "E";
                    if (iTmpH == 15) ret = "F";
                }

                if (iTmpL < 10)
                    ret += iTmpL.ToString();
                else
                {
                    if (iTmpL == 10) ret += "A";
                    if (iTmpL == 11) ret += "B";
                    if (iTmpL == 12) ret += "C";
                    if (iTmpL == 13) ret += "D";
                    if (iTmpL == 14) ret += "E";
                    if (iTmpL == 15) ret += "F";
                }

                return ret;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return "";
            }
        }





        //------------------------------------------------------------------------------------------------
        //
        // StrDec <-> Byte

        private byte StrDecToByte(string sDec)
        {
            try
            {
                bNoError = true;
                return byte.Parse(sDec);
            }
            catch (Exception ex)
            {
                bNoError = false;
                return 0;
            }
        }



        //функция преобразования Байта в 10-ричную строку
        private string ByteToStrDec(byte b)
        {
            try
            {
                return b.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return "";
            }
        }




        //------------------------------------------------------------------------------------------------
        //
        // StrDec <-> StrHex

        //функция преобразования 10-ричной строки в 16-ричную строку
        private string StrDecToStrHex(string sDec)
        {
            try
            {
                bNoError = true;
                byte b = StrDecToByte(sDec);

                if (!bNoError)
                    return "";

                return ByteToStrHex(b);
            }
            catch (Exception ex)
            {
                bNoError = false;
                return "";
            }
        }

        //функция преобразования 16-ричной строки в 10-ричную строку
        private string StrHexToStrDec(string sHex)
        {
            try
            {
                bNoError = true;
                byte b = StrHexToByte(sHex);

                if (!bNoError)
                    return "";

                return ByteToStrDec(b);
            }
            catch (Exception ex)
            {
                bNoError = false;
                return "";
            }
        }









        //обработчик события нажатия кнопки "Очистить"
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            listProcess.Items.Clear();
        }


        //функция деактивации полей ввода данных и их надписей
        private void setVisText()
        {
            try
            {
                int vis = 0;
                foreach (TextBox crl in txtDataArray)	//проходим все текстовые поля в массиве
                {
                    crl.Enabled = false;			//отключаем их
                    if (vis < nmSendQty.Value)		//если необходимо активировать
                        crl.Enabled = true;//активируем
                    vis++;//наращиваем счетчик
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }


        //обработчик события выделения текста в текстовом поле
        public void eventTextSelects(object sender, EventArgs e)
        {
            TextBox b = (TextBox)sender;
            b.SelectAll();
        }


        public void eventTextChanges(object sender, EventArgs e)
        {
            TextBox b = (TextBox)sender;
            b.ForeColor = Color.Black;
        }



        //обработчик события изменения значения в поле ввода байт для отправления
        private void nmSendQty_ValueChanged(object sender, EventArgs e)
        {
            setVisText();
        }



        //обработчик события нажатия на кнопку HEX(формат данных 16-ричный)
        private void optHex_Click(object sender, EventArgs e)
        {
            try
            {
                if (optHex.Checked)	    //если нам нужно преобразовать данные из 10-тичного формата в 16-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrDecToStrHex(crl.Text);
                }
                else	//если нужно преобразовать из 16-тичного формата в 10-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrHexToStrDec(crl.Text);
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
        //обработчик события нажатия на кнопку DEC(формат данных 10-ричный)
        private void optDec_Click(object sender, EventArgs e)
        {
            try
            {
                if (optHex.Checked)	    //если нам нужно преобразовать данные из 10-тичного формата в 16-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrDecToStrHex(crl.Text);
                }
                else	//если нужно преобразовать из 16-тичного формата в 10-ричный
                {
                    foreach (TextBox crl in txtDataArray)
                        crl.Text = StrHexToStrDec(crl.Text);
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		

		


		
		
		//обработчик события изменения текста в поле ввода номера порта
		private void txtPort_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TextBox b = (TextBox)sender;
                string s = b.Text;
                string ss = "";
                char c;
                int i;
            
                for (int j = 0; j < s.Length; j++)//проходим по всем символам текстового поля
                {
                    c = s[j];
                    i = c;
                    if (i >= 48 && i <= 57) //если это символы 0-9 - значит ввод правильный, иначе отсеиваем этот символ
                       ss = ss + c;
                }

                if (ss.Length > 0)//если номер порта больше 64000 выводим 64000
                {
                    i = Int32.Parse(ss);
                    if (i > 64000)
                        ss = "64000";
                }
			    b.Text = ss;
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		
		
		//функция обновления компонента ListView
		public void listViewUpdate(string param1, string param2, string param3)//функция обновления компонента ListView
        {
            try
            {
                if (this.listProcess.InvokeRequired)//если компонент вызывается из другого потока
                {
                    listViewUpdateCallBack d = new listViewUpdateCallBack(listViewUpdate);//создаем делегат
                    this.Invoke(d, new object[] { param1, param2, param3 });//вызываем делегат
                }
                else//иначе обновляем компонент
                {
                    this.listProcess.Items.Add(param1);
                    this.listProcess.Items[listProcess.Items.Count-1].SubItems.Add(param2);
                    this.listProcess.Items[listProcess.Items.Count - 1].SubItems.Add(param3);
                    this.listProcess.Items[listProcess.Items.Count - 1].ImageIndex = 1;
                    this.listProcess.EnsureVisible(listProcess.Items.Count - 1);
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
		
        
		void LabelURLClick(object sender, EventArgs e)
        {
            try
            {
        	System.Diagnostics.Process.Start("http://www.vkmodule.com.ua");
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
        
		
        
        
        
        void ChkStreamingCheckedChanged(object sender, EventArgs e)
        {
            try
            {
        	    if (chkStreaming.Checked)
        	    {
        		    tmrMain.Interval = int.Parse(cmbSendPeriod.Text);
		       	    tmrMain.Start();
       			
        		    btnSend.Enabled = false;
        	    }
        	    else
        	    {
        		    tmrMain.Stop();
        		    btnSend.Enabled = true;
        	    }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }
        
        void TmrMainTick(object sender, EventArgs e)
        {
            try
            {
                tmrMain.Interval = int.Parse(cmbSendPeriod.Text);
                btnSend_Click(this, null);
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //MessageBox.Show("Closing", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);            
                if (clientSocket.Connected)
                {
                    ctThread.Abort();

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listProcess.Items.Add(DT + " (Disconnected)");
                    this.listProcess.EnsureVisible(listProcess.Items.Count - 1);
                    clientSocket.Client.Disconnect(true);
                    //формируем строку с датой отключения, добавляем ее в ListView и отключаемся
                }
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }






        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //  SELECTED NJ CLIPBOARD

        private void mnuSelToCpbAll_Click(object sender, EventArgs e)
        {
            try
            {
                if (listProcess.SelectedItems.Count < 1)
                    return;

                string sText = "";
                foreach (ListViewItem lvi in listProcess.SelectedItems)
                {
                    sText += lvi.Text + " - " + lvi.SubItems[1].Text + " - " + lvi.SubItems[2].Text + "\r\n";
                }
                Clipboard.SetText(sText);
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }

        private void mnuSelToCpbData_Click(object sender, EventArgs e)
        {
            try
            {
                if (listProcess.SelectedItems.Count < 1)
                    return;

                string sText = "";
                foreach (ListViewItem lvi in listProcess.SelectedItems)
                {
                    sText += lvi.SubItems[2].Text + "\r\n";
                }
                Clipboard.SetText(sText);
            }
            catch (Exception ex) { lblStat.Text = ex.Message; }
        }

    }

}
