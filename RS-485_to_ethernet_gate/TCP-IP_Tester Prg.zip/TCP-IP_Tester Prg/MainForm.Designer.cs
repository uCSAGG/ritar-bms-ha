﻿namespace TCP_IP_Tester
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnSend = new System.Windows.Forms.Button();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtData0 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtData31 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtData2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtData30 = new System.Windows.Forms.TextBox();
            this.txtData15 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txtData29 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtData28 = new System.Windows.Forms.TextBox();
            this.txtData14 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtData27 = new System.Windows.Forms.TextBox();
            this.txtData13 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtData26 = new System.Windows.Forms.TextBox();
            this.txtData12 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtData25 = new System.Windows.Forms.TextBox();
            this.txtData11 = new System.Windows.Forms.TextBox();
            this.txtData1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtData24 = new System.Windows.Forms.TextBox();
            this.txtData10 = new System.Windows.Forms.TextBox();
            this.txtData16 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtData9 = new System.Windows.Forms.TextBox();
            this.txtData3 = new System.Windows.Forms.TextBox();
            this.txtData17 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtData8 = new System.Windows.Forms.TextBox();
            this.txtData4 = new System.Windows.Forms.TextBox();
            this.txtData18 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtData5 = new System.Windows.Forms.TextBox();
            this.txtData19 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtData6 = new System.Windows.Forms.TextBox();
            this.txtData20 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtData7 = new System.Windows.Forms.TextBox();
            this.txtData21 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtData22 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtData23 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.cmbSendPeriod = new System.Windows.Forms.ComboBox();
            this.chkStreaming = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.nmSendQty = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.optHex = new System.Windows.Forms.RadioButton();
            this.optDec = new System.Windows.Forms.RadioButton();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.listProcess = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tmrMain = new System.Windows.Forms.Timer(this.components);
            this.labelURL = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.statStrip = new System.Windows.Forms.StatusStrip();
            this.lblStat = new System.Windows.Forms.ToolStripStatusLabel();
            this.ctxMnu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuSelToCpbAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSelToCpbData = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSendQty)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.statStrip.SuspendLayout();
            this.ctxMnu.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(356, 98);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(107, 42);
            this.btnSend.TabIndex = 44;
            this.btnSend.Text = "Send once";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(27, 139);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(79, 20);
            this.txtPort.TabIndex = 2;
            this.txtPort.Text = "9761";
            this.txtPort.TextChanged += new System.EventHandler(this.txtPort_TextChanged);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(113, 98);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(96, 29);
            this.btnConnect.TabIndex = 3;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClearAll.Location = new System.Drawing.Point(222, 132);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(96, 29);
            this.btnClearAll.TabIndex = 45;
            this.btnClearAll.Text = "Clear history";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Location = new System.Drawing.Point(113, 132);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(96, 29);
            this.btnDisconnect.TabIndex = 4;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtData0);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtData31);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtData2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.txtData30);
            this.groupBox1.Controls.Add(this.txtData15);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.txtData29);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.txtData28);
            this.groupBox1.Controls.Add(this.txtData14);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.txtData27);
            this.groupBox1.Controls.Add(this.txtData13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txtData26);
            this.groupBox1.Controls.Add(this.txtData12);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.txtData25);
            this.groupBox1.Controls.Add(this.txtData11);
            this.groupBox1.Controls.Add(this.txtData1);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtData24);
            this.groupBox1.Controls.Add(this.txtData10);
            this.groupBox1.Controls.Add(this.txtData16);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtData9);
            this.groupBox1.Controls.Add(this.txtData3);
            this.groupBox1.Controls.Add(this.txtData17);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtData8);
            this.groupBox1.Controls.Add(this.txtData4);
            this.groupBox1.Controls.Add(this.txtData18);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txtData5);
            this.groupBox1.Controls.Add(this.txtData19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtData6);
            this.groupBox1.Controls.Add(this.txtData20);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtData7);
            this.groupBox1.Controls.Add(this.txtData21);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.txtData22);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.txtData23);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.cmbSendPeriod);
            this.groupBox1.Controls.Add(this.chkStreaming);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.btnSend);
            this.groupBox1.Location = new System.Drawing.Point(324, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(471, 155);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Packet data";
            // 
            // txtData0
            // 
            this.txtData0.Location = new System.Drawing.Point(8, 27);
            this.txtData0.MaxLength = 3;
            this.txtData0.Name = "txtData0";
            this.txtData0.Size = new System.Drawing.Size(26, 20);
            this.txtData0.TabIndex = 92;
            this.txtData0.Text = "00";
            this.txtData0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(16, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 12);
            this.label5.TabIndex = 100;
            this.label5.Text = "0";
            // 
            // txtData31
            // 
            this.txtData31.Enabled = false;
            this.txtData31.Location = new System.Drawing.Point(436, 64);
            this.txtData31.MaxLength = 3;
            this.txtData31.Name = "txtData31";
            this.txtData31.Size = new System.Drawing.Size(26, 20);
            this.txtData31.TabIndex = 154;
            this.txtData31.Text = "00";
            this.txtData31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(44, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 12);
            this.label6.TabIndex = 101;
            this.label6.Text = "1";
            // 
            // txtData2
            // 
            this.txtData2.Enabled = false;
            this.txtData2.Location = new System.Drawing.Point(65, 27);
            this.txtData2.MaxLength = 3;
            this.txtData2.Name = "txtData2";
            this.txtData2.Size = new System.Drawing.Size(26, 20);
            this.txtData2.TabIndex = 94;
            this.txtData2.Text = "00";
            this.txtData2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(441, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 12);
            this.label3.TabIndex = 155;
            this.label3.Text = "31";
            // 
            // label2
            // 
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(16, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 12);
            this.label2.TabIndex = 132;
            this.label2.Text = "16";
            // 
            // label7
            // 
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(75, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 12);
            this.label7.TabIndex = 102;
            this.label7.Text = "2";
            // 
            // label34
            // 
            this.label34.Enabled = false;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.Location = new System.Drawing.Point(44, 51);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 12);
            this.label34.TabIndex = 133;
            this.label34.Text = "17";
            // 
            // txtData30
            // 
            this.txtData30.Enabled = false;
            this.txtData30.Location = new System.Drawing.Point(409, 64);
            this.txtData30.MaxLength = 3;
            this.txtData30.Name = "txtData30";
            this.txtData30.Size = new System.Drawing.Size(26, 20);
            this.txtData30.TabIndex = 146;
            this.txtData30.Text = "00";
            this.txtData30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData15
            // 
            this.txtData15.Enabled = false;
            this.txtData15.Location = new System.Drawing.Point(436, 27);
            this.txtData15.MaxLength = 3;
            this.txtData15.Name = "txtData15";
            this.txtData15.Size = new System.Drawing.Size(26, 20);
            this.txtData15.TabIndex = 122;
            this.txtData15.Text = "00";
            this.txtData15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(102, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 12);
            this.label8.TabIndex = 103;
            this.label8.Text = "3";
            // 
            // label33
            // 
            this.label33.Enabled = false;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.Location = new System.Drawing.Point(75, 51);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 12);
            this.label33.TabIndex = 134;
            this.label33.Text = "18";
            // 
            // txtData29
            // 
            this.txtData29.Enabled = false;
            this.txtData29.Location = new System.Drawing.Point(380, 64);
            this.txtData29.MaxLength = 3;
            this.txtData29.Name = "txtData29";
            this.txtData29.Size = new System.Drawing.Size(26, 20);
            this.txtData29.TabIndex = 145;
            this.txtData29.Text = "00";
            this.txtData29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.Enabled = false;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(441, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 12);
            this.label4.TabIndex = 123;
            this.label4.Text = "15";
            // 
            // label9
            // 
            this.label9.Enabled = false;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(130, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 12);
            this.label9.TabIndex = 104;
            this.label9.Text = "4";
            // 
            // label32
            // 
            this.label32.Enabled = false;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(102, 51);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(15, 12);
            this.label32.TabIndex = 135;
            this.label32.Text = "19";
            // 
            // txtData28
            // 
            this.txtData28.Enabled = false;
            this.txtData28.Location = new System.Drawing.Point(351, 64);
            this.txtData28.MaxLength = 3;
            this.txtData28.Name = "txtData28";
            this.txtData28.Size = new System.Drawing.Size(26, 20);
            this.txtData28.TabIndex = 144;
            this.txtData28.Text = "00";
            this.txtData28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData14
            // 
            this.txtData14.Enabled = false;
            this.txtData14.Location = new System.Drawing.Point(409, 27);
            this.txtData14.MaxLength = 3;
            this.txtData14.Name = "txtData14";
            this.txtData14.Size = new System.Drawing.Size(26, 20);
            this.txtData14.TabIndex = 114;
            this.txtData14.Text = "00";
            this.txtData14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.Enabled = false;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(159, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 12);
            this.label10.TabIndex = 105;
            this.label10.Text = "5";
            // 
            // label31
            // 
            this.label31.Enabled = false;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(130, 51);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(15, 12);
            this.label31.TabIndex = 136;
            this.label31.Text = "20";
            // 
            // txtData27
            // 
            this.txtData27.Enabled = false;
            this.txtData27.Location = new System.Drawing.Point(322, 64);
            this.txtData27.MaxLength = 3;
            this.txtData27.Name = "txtData27";
            this.txtData27.Size = new System.Drawing.Size(26, 20);
            this.txtData27.TabIndex = 143;
            this.txtData27.Text = "00";
            this.txtData27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData13
            // 
            this.txtData13.Enabled = false;
            this.txtData13.Location = new System.Drawing.Point(380, 27);
            this.txtData13.MaxLength = 3;
            this.txtData13.Name = "txtData13";
            this.txtData13.Size = new System.Drawing.Size(26, 20);
            this.txtData13.TabIndex = 113;
            this.txtData13.Text = "00";
            this.txtData13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.Enabled = false;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(189, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 12);
            this.label11.TabIndex = 106;
            this.label11.Text = "6";
            // 
            // label30
            // 
            this.label30.Enabled = false;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(159, 51);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(15, 12);
            this.label30.TabIndex = 137;
            this.label30.Text = "21";
            // 
            // txtData26
            // 
            this.txtData26.Enabled = false;
            this.txtData26.Location = new System.Drawing.Point(294, 64);
            this.txtData26.MaxLength = 3;
            this.txtData26.Name = "txtData26";
            this.txtData26.Size = new System.Drawing.Size(26, 20);
            this.txtData26.TabIndex = 142;
            this.txtData26.Text = "00";
            this.txtData26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData12
            // 
            this.txtData12.Enabled = false;
            this.txtData12.Location = new System.Drawing.Point(351, 27);
            this.txtData12.MaxLength = 3;
            this.txtData12.Name = "txtData12";
            this.txtData12.Size = new System.Drawing.Size(26, 20);
            this.txtData12.TabIndex = 112;
            this.txtData12.Text = "00";
            this.txtData12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.Enabled = false;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(216, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 12);
            this.label12.TabIndex = 107;
            this.label12.Text = "7";
            // 
            // label29
            // 
            this.label29.Enabled = false;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(189, 51);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(15, 12);
            this.label29.TabIndex = 138;
            this.label29.Text = "22";
            // 
            // txtData25
            // 
            this.txtData25.Enabled = false;
            this.txtData25.Location = new System.Drawing.Point(265, 64);
            this.txtData25.MaxLength = 3;
            this.txtData25.Name = "txtData25";
            this.txtData25.Size = new System.Drawing.Size(26, 20);
            this.txtData25.TabIndex = 141;
            this.txtData25.Text = "00";
            this.txtData25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData11
            // 
            this.txtData11.Enabled = false;
            this.txtData11.Location = new System.Drawing.Point(322, 27);
            this.txtData11.MaxLength = 3;
            this.txtData11.Name = "txtData11";
            this.txtData11.Size = new System.Drawing.Size(26, 20);
            this.txtData11.TabIndex = 111;
            this.txtData11.Text = "00";
            this.txtData11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData1
            // 
            this.txtData1.Enabled = false;
            this.txtData1.Location = new System.Drawing.Point(36, 27);
            this.txtData1.MaxLength = 3;
            this.txtData1.Name = "txtData1";
            this.txtData1.Size = new System.Drawing.Size(26, 20);
            this.txtData1.TabIndex = 93;
            this.txtData1.Text = "00";
            this.txtData1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label28
            // 
            this.label28.Enabled = false;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(216, 51);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(15, 12);
            this.label28.TabIndex = 139;
            this.label28.Text = "23";
            // 
            // txtData24
            // 
            this.txtData24.Enabled = false;
            this.txtData24.Location = new System.Drawing.Point(237, 64);
            this.txtData24.MaxLength = 3;
            this.txtData24.Name = "txtData24";
            this.txtData24.Size = new System.Drawing.Size(26, 20);
            this.txtData24.TabIndex = 140;
            this.txtData24.Text = "00";
            this.txtData24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData10
            // 
            this.txtData10.Enabled = false;
            this.txtData10.Location = new System.Drawing.Point(294, 27);
            this.txtData10.MaxLength = 3;
            this.txtData10.Name = "txtData10";
            this.txtData10.Size = new System.Drawing.Size(26, 20);
            this.txtData10.TabIndex = 110;
            this.txtData10.Text = "00";
            this.txtData10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData16
            // 
            this.txtData16.Enabled = false;
            this.txtData16.Location = new System.Drawing.Point(8, 64);
            this.txtData16.MaxLength = 3;
            this.txtData16.Name = "txtData16";
            this.txtData16.Size = new System.Drawing.Size(26, 20);
            this.txtData16.TabIndex = 124;
            this.txtData16.Text = "00";
            this.txtData16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.Enabled = false;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(414, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 12);
            this.label13.TabIndex = 153;
            this.label13.Text = "30";
            // 
            // txtData9
            // 
            this.txtData9.Enabled = false;
            this.txtData9.Location = new System.Drawing.Point(265, 27);
            this.txtData9.MaxLength = 3;
            this.txtData9.Name = "txtData9";
            this.txtData9.Size = new System.Drawing.Size(26, 20);
            this.txtData9.TabIndex = 109;
            this.txtData9.Text = "00";
            this.txtData9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData3
            // 
            this.txtData3.Enabled = false;
            this.txtData3.Location = new System.Drawing.Point(93, 27);
            this.txtData3.MaxLength = 3;
            this.txtData3.Name = "txtData3";
            this.txtData3.Size = new System.Drawing.Size(26, 20);
            this.txtData3.TabIndex = 95;
            this.txtData3.Text = "00";
            this.txtData3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData17
            // 
            this.txtData17.Enabled = false;
            this.txtData17.Location = new System.Drawing.Point(36, 64);
            this.txtData17.MaxLength = 3;
            this.txtData17.Name = "txtData17";
            this.txtData17.Size = new System.Drawing.Size(26, 20);
            this.txtData17.TabIndex = 125;
            this.txtData17.Text = "00";
            this.txtData17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label15
            // 
            this.label15.Enabled = false;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(384, 51);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 12);
            this.label15.TabIndex = 152;
            this.label15.Text = "29";
            // 
            // txtData8
            // 
            this.txtData8.Enabled = false;
            this.txtData8.Location = new System.Drawing.Point(237, 27);
            this.txtData8.MaxLength = 3;
            this.txtData8.Name = "txtData8";
            this.txtData8.Size = new System.Drawing.Size(26, 20);
            this.txtData8.TabIndex = 108;
            this.txtData8.Text = "00";
            this.txtData8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData4
            // 
            this.txtData4.Enabled = false;
            this.txtData4.Location = new System.Drawing.Point(122, 27);
            this.txtData4.MaxLength = 3;
            this.txtData4.Name = "txtData4";
            this.txtData4.Size = new System.Drawing.Size(26, 20);
            this.txtData4.TabIndex = 96;
            this.txtData4.Text = "00";
            this.txtData4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData18
            // 
            this.txtData18.Enabled = false;
            this.txtData18.Location = new System.Drawing.Point(65, 64);
            this.txtData18.MaxLength = 3;
            this.txtData18.Name = "txtData18";
            this.txtData18.Size = new System.Drawing.Size(26, 20);
            this.txtData18.TabIndex = 126;
            this.txtData18.Text = "00";
            this.txtData18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.Enabled = false;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(355, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 12);
            this.label16.TabIndex = 151;
            this.label16.Text = "28";
            // 
            // label17
            // 
            this.label17.Enabled = false;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(414, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 12);
            this.label17.TabIndex = 121;
            this.label17.Text = "14";
            // 
            // txtData5
            // 
            this.txtData5.Enabled = false;
            this.txtData5.Location = new System.Drawing.Point(151, 27);
            this.txtData5.MaxLength = 3;
            this.txtData5.Name = "txtData5";
            this.txtData5.Size = new System.Drawing.Size(26, 20);
            this.txtData5.TabIndex = 97;
            this.txtData5.Text = "00";
            this.txtData5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData19
            // 
            this.txtData19.Enabled = false;
            this.txtData19.Location = new System.Drawing.Point(93, 64);
            this.txtData19.MaxLength = 3;
            this.txtData19.Name = "txtData19";
            this.txtData19.Size = new System.Drawing.Size(26, 20);
            this.txtData19.TabIndex = 127;
            this.txtData19.Text = "00";
            this.txtData19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.Enabled = false;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(327, 51);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 12);
            this.label18.TabIndex = 150;
            this.label18.Text = "27";
            // 
            // label19
            // 
            this.label19.Enabled = false;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(384, 13);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 12);
            this.label19.TabIndex = 120;
            this.label19.Text = "13";
            // 
            // txtData6
            // 
            this.txtData6.Enabled = false;
            this.txtData6.Location = new System.Drawing.Point(180, 27);
            this.txtData6.MaxLength = 3;
            this.txtData6.Name = "txtData6";
            this.txtData6.Size = new System.Drawing.Size(26, 20);
            this.txtData6.TabIndex = 98;
            this.txtData6.Text = "00";
            this.txtData6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData20
            // 
            this.txtData20.Enabled = false;
            this.txtData20.Location = new System.Drawing.Point(122, 64);
            this.txtData20.MaxLength = 3;
            this.txtData20.Name = "txtData20";
            this.txtData20.Size = new System.Drawing.Size(26, 20);
            this.txtData20.TabIndex = 128;
            this.txtData20.Text = "00";
            this.txtData20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.Enabled = false;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(300, 51);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(15, 12);
            this.label25.TabIndex = 149;
            this.label25.Text = "26";
            // 
            // label20
            // 
            this.label20.Enabled = false;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(355, 13);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 12);
            this.label20.TabIndex = 119;
            this.label20.Text = "12";
            // 
            // txtData7
            // 
            this.txtData7.Enabled = false;
            this.txtData7.Location = new System.Drawing.Point(208, 27);
            this.txtData7.MaxLength = 3;
            this.txtData7.Name = "txtData7";
            this.txtData7.Size = new System.Drawing.Size(26, 20);
            this.txtData7.TabIndex = 99;
            this.txtData7.Text = "00";
            this.txtData7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtData21
            // 
            this.txtData21.Enabled = false;
            this.txtData21.Location = new System.Drawing.Point(151, 64);
            this.txtData21.MaxLength = 3;
            this.txtData21.Name = "txtData21";
            this.txtData21.Size = new System.Drawing.Size(26, 20);
            this.txtData21.TabIndex = 129;
            this.txtData21.Text = "00";
            this.txtData21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label26
            // 
            this.label26.Enabled = false;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(273, 51);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(15, 12);
            this.label26.TabIndex = 148;
            this.label26.Text = "25";
            // 
            // label21
            // 
            this.label21.Enabled = false;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(327, 13);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(15, 12);
            this.label21.TabIndex = 118;
            this.label21.Text = "11";
            // 
            // label24
            // 
            this.label24.Enabled = false;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(245, 13);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(10, 12);
            this.label24.TabIndex = 115;
            this.label24.Text = "8";
            // 
            // txtData22
            // 
            this.txtData22.Enabled = false;
            this.txtData22.Location = new System.Drawing.Point(180, 64);
            this.txtData22.MaxLength = 3;
            this.txtData22.Name = "txtData22";
            this.txtData22.Size = new System.Drawing.Size(26, 20);
            this.txtData22.TabIndex = 130;
            this.txtData22.Text = "00";
            this.txtData22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label27
            // 
            this.label27.Enabled = false;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(245, 51);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(15, 12);
            this.label27.TabIndex = 147;
            this.label27.Text = "24";
            // 
            // label22
            // 
            this.label22.Enabled = false;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(300, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(15, 12);
            this.label22.TabIndex = 117;
            this.label22.Text = "10";
            // 
            // label23
            // 
            this.label23.Enabled = false;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(273, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(10, 12);
            this.label23.TabIndex = 116;
            this.label23.Text = "9";
            // 
            // txtData23
            // 
            this.txtData23.Enabled = false;
            this.txtData23.Location = new System.Drawing.Point(208, 64);
            this.txtData23.MaxLength = 3;
            this.txtData23.Name = "txtData23";
            this.txtData23.Size = new System.Drawing.Size(26, 20);
            this.txtData23.TabIndex = 131;
            this.txtData23.Text = "00";
            this.txtData23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(308, 125);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(31, 18);
            this.label38.TabIndex = 91;
            this.label38.Text = "ms";
            // 
            // cmbSendPeriod
            // 
            this.cmbSendPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSendPeriod.FormattingEnabled = true;
            this.cmbSendPeriod.Items.AddRange(new object[] {
            "50",
            "200",
            "300",
            "500",
            "1000",
            "2000",
            "3000",
            "5000"});
            this.cmbSendPeriod.Location = new System.Drawing.Point(238, 119);
            this.cmbSendPeriod.Name = "cmbSendPeriod";
            this.cmbSendPeriod.Size = new System.Drawing.Size(64, 21);
            this.cmbSendPeriod.TabIndex = 90;
            // 
            // chkStreaming
            // 
            this.chkStreaming.Location = new System.Drawing.Point(238, 94);
            this.chkStreaming.Name = "chkStreaming";
            this.chkStreaming.Size = new System.Drawing.Size(108, 21);
            this.chkStreaming.TabIndex = 88;
            this.chkStreaming.Text = "Send periodically";
            this.chkStreaming.UseVisualStyleBackColor = true;
            this.chkStreaming.CheckedChanged += new System.EventHandler(this.ChkStreamingCheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nmSendQty);
            this.groupBox4.Location = new System.Drawing.Point(122, 94);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(102, 48);
            this.groupBox4.TabIndex = 82;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Number of bytes";
            // 
            // nmSendQty
            // 
            this.nmSendQty.Location = new System.Drawing.Point(27, 19);
            this.nmSendQty.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.nmSendQty.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmSendQty.Name = "nmSendQty";
            this.nmSendQty.Size = new System.Drawing.Size(48, 20);
            this.nmSendQty.TabIndex = 43;
            this.nmSendQty.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nmSendQty.ValueChanged += new System.EventHandler(this.nmSendQty_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.optHex);
            this.groupBox2.Controls.Add(this.optDec);
            this.groupBox2.Location = new System.Drawing.Point(10, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(108, 48);
            this.groupBox2.TabIndex = 80;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Data Format";
            // 
            // optHex
            // 
            this.optHex.AutoSize = true;
            this.optHex.Checked = true;
            this.optHex.Location = new System.Drawing.Point(9, 18);
            this.optHex.Name = "optHex";
            this.optHex.Size = new System.Drawing.Size(42, 17);
            this.optHex.TabIndex = 39;
            this.optHex.TabStop = true;
            this.optHex.Text = "hex";
            this.optHex.UseVisualStyleBackColor = true;
            this.optHex.Click += new System.EventHandler(this.optHex_Click);
            // 
            // optDec
            // 
            this.optDec.AutoSize = true;
            this.optDec.Location = new System.Drawing.Point(57, 18);
            this.optDec.Name = "optDec";
            this.optDec.Size = new System.Drawing.Size(43, 17);
            this.optDec.TabIndex = 40;
            this.optDec.TabStop = true;
            this.optDec.Text = "dec";
            this.optDec.UseVisualStyleBackColor = true;
            this.optDec.Click += new System.EventHandler(this.optDec_Click);
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(27, 99);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(79, 20);
            this.maskedTextBox2.TabIndex = 1;
            this.maskedTextBox2.Text = "192.168.0.191";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "1.jpg");
            this.imageList1.Images.SetKeyName(1, "2.jpg");
            // 
            // listProcess
            // 
            this.listProcess.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listProcess.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listProcess.ContextMenuStrip = this.ctxMnu;
            this.listProcess.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listProcess.HideSelection = false;
            this.listProcess.Location = new System.Drawing.Point(-2, 173);
            this.listProcess.Name = "listProcess";
            this.listProcess.Size = new System.Drawing.Size(805, 354);
            this.listProcess.SmallImageList = this.imageList1;
            this.listProcess.TabIndex = 46;
            this.listProcess.UseCompatibleStateImageBehavior = false;
            this.listProcess.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Date";
            this.columnHeader1.Width = 180;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Size";
            this.columnHeader2.Width = 35;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Data";
            this.columnHeader3.Width = 560;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 47;
            this.label1.Text = "IP address:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(8, 123);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(29, 13);
            this.label35.TabIndex = 48;
            this.label35.Text = "Port:";
            // 
            // tmrMain
            // 
            this.tmrMain.Interval = 500;
            this.tmrMain.Tick += new System.EventHandler(this.TmrMainTick);
            // 
            // labelURL
            // 
            this.labelURL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelURL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(100)))), ((int)(((byte)(0)))));
            this.labelURL.Location = new System.Drawing.Point(89, 4);
            this.labelURL.Name = "labelURL";
            this.labelURL.Size = new System.Drawing.Size(127, 22);
            this.labelURL.TabIndex = 57;
            this.labelURL.Text = "vkmodule.com.ua";
            this.labelURL.Click += new System.EventHandler(this.LabelURLClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(7, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(195, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 59;
            this.pictureBox2.TabStop = false;
            // 
            // statStrip
            // 
            this.statStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStat});
            this.statStrip.Location = new System.Drawing.Point(0, 526);
            this.statStrip.Name = "statStrip";
            this.statStrip.Size = new System.Drawing.Size(803, 22);
            this.statStrip.TabIndex = 61;
            this.statStrip.Text = "statusStrip1";
            // 
            // lblStat
            // 
            this.lblStat.ForeColor = System.Drawing.Color.Red;
            this.lblStat.Name = "lblStat";
            this.lblStat.Size = new System.Drawing.Size(40, 17);
            this.lblStat.Text = "lblStat";
            this.lblStat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ctxMnu
            // 
            this.ctxMnu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuSelToCpbAll,
            this.mnuSelToCpbData});
            this.ctxMnu.Name = "ctxMnu";
            this.ctxMnu.Size = new System.Drawing.Size(221, 48);
            // 
            // mnuSelToCpbAll
            // 
            this.mnuSelToCpbAll.Name = "mnuSelToCpbAll";
            this.mnuSelToCpbAll.Size = new System.Drawing.Size(220, 22);
            this.mnuSelToCpbAll.Text = "Selected to clipboard (All)";
            this.mnuSelToCpbAll.Click += new System.EventHandler(this.mnuSelToCpbAll_Click);
            // 
            // mnuSelToCpbData
            // 
            this.mnuSelToCpbData.Name = "mnuSelToCpbData";
            this.mnuSelToCpbData.Size = new System.Drawing.Size(220, 22);
            this.mnuSelToCpbData.Text = "Selected to clipboard (Data)";
            this.mnuSelToCpbData.Click += new System.EventHandler(this.mnuSelToCpbData_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 548);
            this.Controls.Add(this.statStrip);
            this.Controls.Add(this.labelURL);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listProcess);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.maskedTextBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtPort);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(811, 431);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TCP/IP  Tester";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmSendQty)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.statStrip.ResumeLayout(false);
            this.statStrip.PerformLayout();
            this.ctxMnu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Timer tmrMain;
        private System.Windows.Forms.CheckBox chkStreaming;
        private System.Windows.Forms.Label labelURL;

        #endregion

        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nmSendQty;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.RadioButton optDec;
        private System.Windows.Forms.RadioButton optHex;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ListView listProcess;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.StatusStrip statStrip;
        private System.Windows.Forms.ToolStripStatusLabel lblStat;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cmbSendPeriod;
        private System.Windows.Forms.TextBox txtData0;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtData31;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtData2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtData30;
        private System.Windows.Forms.TextBox txtData15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtData29;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtData28;
        private System.Windows.Forms.TextBox txtData14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtData27;
        private System.Windows.Forms.TextBox txtData13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtData26;
        private System.Windows.Forms.TextBox txtData12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtData25;
        private System.Windows.Forms.TextBox txtData11;
        private System.Windows.Forms.TextBox txtData1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtData24;
        private System.Windows.Forms.TextBox txtData10;
        private System.Windows.Forms.TextBox txtData16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtData9;
        private System.Windows.Forms.TextBox txtData3;
        private System.Windows.Forms.TextBox txtData17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtData8;
        private System.Windows.Forms.TextBox txtData4;
        private System.Windows.Forms.TextBox txtData18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtData5;
        private System.Windows.Forms.TextBox txtData19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtData6;
        private System.Windows.Forms.TextBox txtData20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtData7;
        private System.Windows.Forms.TextBox txtData21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtData22;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtData23;
        private System.Windows.Forms.ContextMenuStrip ctxMnu;
        private System.Windows.Forms.ToolStripMenuItem mnuSelToCpbAll;
        private System.Windows.Forms.ToolStripMenuItem mnuSelToCpbData;
    }
}

